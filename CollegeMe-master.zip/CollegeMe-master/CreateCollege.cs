﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollegeMe
{
    //COULD MAKE THIS A GROUP BOX, WORK ON THAT WHEN CAUGHT UP
    public partial class CreateCollege : Form
    {
        public CreateCollege()
        {
            InitializeComponent();
        }

        private void CreateCollege_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Program.collegeDictionary.ContainsKey(nameCollege.Text))
            {
                MessageBox.Show("That college already exists, please delete first!");
                return;
            }
            
            if (String.IsNullOrEmpty(nameCollege.Text))
            {
                MessageBox.Show("Enter Something");
            }
            else
            {
                MessageBox.Show(nameCollege.Text + " created!");
                

                Program.collegeDictionary.Add(nameCollege.Text, dateTimePicker1.Value);
                nameCollege.Clear();
                
            }
            Program.seralizeColleges(Program.collegeDictionary);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            var form = new Form1();
            form.FormClosing += (a, b) => Close();
            Hide();
            form.Show();
        }

        private void nameCollege_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
