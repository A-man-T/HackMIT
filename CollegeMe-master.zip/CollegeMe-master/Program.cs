﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;
using System.Windows.Forms;

namespace CollegeMe
{
    static class Program
    {
        public const string writeto = "saveFile.txt";
        public static Dictionary<string, DateTime> collegeDictionary = new Dictionary<string, DateTime>();
       // public static Dictionary<string, DateTime> collegeDictionary = JsonConvert.DeserializeObject<Dictionary<string, string>>(json);
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]

        public static String printColleges() {
            foreach (KeyValuePair<string, DateTime> kvp in Program.collegeDictionary.OrderBy(key => key.Value))
            {
                return (String.Format("{0}({1})", kvp.Key + " ", kvp.Value.ToString()));
            }
                return null;
        }

        public static void seralizeColleges(Dictionary<string, DateTime> currentstate)
        {
            string json = JsonConvert.SerializeObject(currentstate, Formatting.Indented);
            //MessageBox.Show(json);
            


            if (!File.Exists(writeto)) // If file does not exists
            {
                File.Create(writeto).Close(); // Create file
                
                using (StreamWriter sw = File.AppendText(writeto))
                {
                    sw.WriteLine(json); // Write text to .txt file
                }
                

            }
            
            else // If file already exists
            {
                File.WriteAllText(writeto, String.Empty); // Clear file

                
                using (StreamWriter sw = File.AppendText(writeto))
                {
                    sw.WriteLine(json); // Write text to .txt file
                }
                
            }
                
           
        }

        static void Main()
        {
            if (File.Exists(writeto)) {
                string contents = File.ReadAllText(writeto);
                collegeDictionary = JsonConvert.DeserializeObject<Dictionary<string, DateTime>>(contents);
            }
                
            
            
            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LoginForm());

            

        }
    }
}
