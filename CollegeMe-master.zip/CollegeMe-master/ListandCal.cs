﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollegeMe
{
    public partial class ListandCal : Form
    {
        public ListandCal()
        {
            InitializeComponent();
            this.CenterToScreen();
            updateList(collegeBox);
        }

        private void ListandCal_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
            
        }



        public static void updateCalender(MonthCalendar cal)
        {

                
        }
        public static void updateList(ListBox List)
        {
            List.Items.Clear();
            foreach (KeyValuePair<string, DateTime> kvp in Program.collegeDictionary.OrderBy(key => key.Value))
            {
                List.Items.Add(String.Format("{0}({1})", kvp.Key + "  Due: ", kvp.Value.ToString()));
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
           
        }


        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void collegeBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Hide();
            var newCreate = new CreateCollege();
            newCreate.Show(this);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Hide();
            var newCreate = new DeleteCollege();
            newCreate.Show(this);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Hide();
            var newCreate = new Form1();
            newCreate.Show(this);
        }
    }
}
