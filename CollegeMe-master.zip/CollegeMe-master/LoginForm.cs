﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollegeMe
{ 
    public partial class LoginForm : Form
    {
        public const string Password = "admin";
        public LoginForm()
        {
            InitializeComponent();
        }

        private async void LoginButton_Click(object sender, EventArgs e)
        {
            SetControlState(true);
            
            await Task.Run(() => Thread.Sleep(1 * 500));
            SetControlState(false);

            if (PasswordTextBox.Text == Password)
            {
                var form = new Form1();
                form.FormClosing += (a, b) => Close();
                Hide();
                form.Show();
            }
            else
                MessageBox.Show("Try again!");
        }

        protected void SetControlState(bool loading)
        {
            LoginButton.Enabled = !loading;
           
            PasswordTextBox.Enabled = !loading;
            
            LoginProgressBar.Style = loading ? ProgressBarStyle.Marquee : ProgressBarStyle.Blocks;
        }

 
    }
}
