﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollegeMe
{
    public partial class Form1 : Form
    {
        //Dictionary<string, DateTime> collegeDictionary = new Dictionary<string, DateTime>();

        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Program.collegeDictionary.Count == 0)
                MessageBox.Show("Please create a college first");
            else { 
                var notes = new addNotes();
                Hide();
                notes.Show(this);
                }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            //Program.collegeDictionary.ToList().ForEach(x => Console.WriteLine(x.Key));
            /*
            foreach (KeyValuePair<string, DateTime> ele1 in Program.collegeDictionary)
            {
                MessageBox.Show(ele1.Key + ele1.Value);
            }
            */
            if (Program.collegeDictionary.Count == 0)
                MessageBox.Show("Please create a college first");
            else
            {
                Hide();
                var ListandCalForm = new ListandCal();
                ListandCalForm.Show(this);
            }

        }

        private void btnManage_Click(object sender, EventArgs e)
        {
            var formPopup = new AddorDeletePopup();
            Hide();
            formPopup.Show(this);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            var form = new LoginForm();
            form.FormClosing += (a, b) => Close();
            Hide();
            form.Show();
        }
    }
}
