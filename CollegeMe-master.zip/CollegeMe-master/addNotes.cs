﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;


namespace CollegeMe
{
    
    public partial class addNotes : Form
    {
        string writeto;
        public addNotes()
        {
            InitializeComponent();
            this.CenterToScreen();
            comboBox1.Items.Clear();
            foreach (KeyValuePair<string, DateTime> kvp in Program.collegeDictionary.OrderBy(key => key.Value))
            {
                comboBox1.Items.Add(String.Format("{0}({1})", kvp.Key + " Due: ", kvp.Value.ToString()));
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //String FILENAME;
            String collegeToRemove = comboBox1.GetItemText(comboBox1.SelectedItem);
            int cut = collegeToRemove.IndexOf(" Due:");
            String FILENAME = collegeToRemove.Substring(0, cut);
            
            writeto = FILENAME + ".txt";
            //MessageBox.Show(writeto);

            if (!File.Exists(writeto)) // If file does not exists
            {
                File.Create(writeto).Close(); // Create file
                /*
                using (StreamWriter sw = File.AppendText(writeto))
                {
                    sw.WriteLine("WRITE SOME TEXT"); // Write text to .txt file
                }
                */
                
            }
            /*
            else // If file already exists
            {
                // File.WriteAllText("FILENAME.txt", String.Empty); // Clear file

                
                using (StreamWriter sw = File.AppendText(writeto))
                {
                    sw.WriteLine("WRITE SOME TEXT"); // Write text to .txt file
                }
                
            }
                */
            richTextBox1.LoadFile(writeto, RichTextBoxStreamType.PlainText);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var form = new Form1();
            form.FormClosing += (a, b) => Close();
            Hide();
            form.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (writeto == null)
            {
                MessageBox.Show("Select a Valid College");
                return;
            }
            else
            {
                richTextBox1.SaveFile(writeto, RichTextBoxStreamType.PlainText);
                MessageBox.Show("Saved");
            }
        }
    }
}
