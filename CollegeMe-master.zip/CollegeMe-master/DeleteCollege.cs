﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace CollegeMe
{
    public partial class DeleteCollege: Form
    {
        public DeleteCollege()
        {
            InitializeComponent();
            this.CenterToScreen();
            ListandCal.updateList(collegeBox);
            //Program.collegeDictionary.DataSource = new BindingSource(Program.collegeDictionary, null);

            //foreach (KeyValuePair<string, DateTime> kvp in Program.collegeDictionary.OrderBy(key => key.Value))
            //{
              //  collegeBox.Items.Add(String.Format("{0}({1})", kvp.Key + " ", kvp.Value.ToString()));
            //}
        }

        private void DeleteCollege_Load(object sender, EventArgs e)
        {

        }

        private void collegeBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            var newCreate = new Form1();
            newCreate.Show(this);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int delete = collegeBox.SelectedIndex;
            String collegeToRemove = collegeBox.GetItemText(collegeBox.SelectedItem);
            if (delete > Program.collegeDictionary.Count | delete < 0)
            {
                MessageBox.Show("Select a Valid College");
                return;
            }

            int cut = collegeToRemove.IndexOf(" Due:");
            String key = collegeToRemove.Substring(0, cut-1);
            Program.collegeDictionary.Remove(key);
            if (File.Exists(key + ".txt")) {
                File.Delete(key + ".txt");
            }
            ListandCal.updateList(collegeBox);
            Program.seralizeColleges(Program.collegeDictionary);

        }
    }
}
