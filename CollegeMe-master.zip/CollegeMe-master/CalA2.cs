﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CompSciIA
{
    
    Dim lblDayz As Label
    Dim y As Int32 = 0
    Dim x As Int32
    Dim ndayz As Int32
    Dim Dayofweek, CurrentCulture As String
    public partial class CalA2 : Form
    {
        public CalA2()
        {
            InitializeComponent();
        }
        private sub CalA2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'display the current month
        comboBoxMonth.Text = DateTime.Now.Month.ToString()
        'Get there windows culture
        CurrentCulture = Globalization.CultureInfo.CurrentCulture.Name
        'display the full name of the current month
        labelMonth.Text = Application.CurrentCulture.DateTimeFormat.GetMonthName(Convert.ToInt32(comboBoxMonth.Text))
        'get the number of days in the selected month and year
        My.Application.ChangeCulture("en-za")
        Dim Dayz As Int32 = DateTime.DaysInMonth(DateTime.Now.Year, DateTime.Now.Month)
        'display the current year in the textbox
        textBoxYear.Text = DateTime.Now.Year.ToString()
        'call the checkday function
        CheckDay()
        For i As Int32 = 1 To Dayz
            ndayz += 1
            lblDayz = New Label()
            lblDayz.Name = "B" & i
            lblDayz.Text = i.ToString()
            lblDayz.BorderStyle = BorderStyle.Fixed3D
            If i = DateTime.Now.Day Then
                lblDayz.BackColor = Color.Green
            ElseIf ndayz = 1 Then
                lblDayz.BackColor = Color.Red
            Else
                lblDayz.BackColor = Color.Aquamarine
            End If
            lblDayz.Font = label31.Font
            lblDayz.SetBounds(x, y, 37, 27)
            x += 42
            If ndayz = 7 Then
                x = 0
                ndayz = 0
                y += 29
            End If
            panel1.Controls.Add(lblDayz)
        Next
        'return all values to default
        x = 0
        ndayz = 0
        y = 0
    End Sub
        }
        Function CheckDay() As Int32
        Dim time As DateTime = Convert.ToDateTime(comboBoxMonth.Text + "/01/" + textBoxYear.Text)
        'get the start day of the week for the entered date and month
        Dayofweek = Application.CurrentCulture.Calendar.GetDayOfWeek(time).ToString()
        If Dayofweek = "Sunday" Then
            x = 0
        ElseIf Dayofweek = "Monday" Then
            x = 0 + 42
            ndayz = 1
        ElseIf Dayofweek = "Tuesday" Then
            x = 0 + 84
            ndayz = 2
        ElseIf Dayofweek = "Wednesday" Then
            x = 0 + 84 + 42
            ndayz = 3
        ElseIf Dayofweek = "Thursday" Then
            x = 0 + 84 + 84
            ndayz = 4
        ElseIf Dayofweek = "Friday" Then
            x = 0 + 84 + 84 + 42
            ndayz = 5
        ElseIf Dayofweek = "Saturday" Then
            x = 0 + 84 + 84 + 84
            ndayz = 6
        End If
        Return x


    End Function
    }
}
