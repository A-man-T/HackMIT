﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollegeMe
{
    public partial class AddorDeletePopup : Form
    {
        public AddorDeletePopup()
        {
            InitializeComponent();
            this.CenterToScreen();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var form = new CreateCollege();
            form.FormClosing += (a, b) => Close();
            Hide();
            form.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            var form = new Form1();
            form.FormClosing += (a, b) => Close();
            Hide();
            form.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (Program.collegeDictionary.Count == 0)
                MessageBox.Show("Please create a college first");
            else
            {
                var form = new DeleteCollege();
                form.FormClosing += (a, b) => Close();
                Hide();
                form.Show();
            }
            
            
        }
    }
}
